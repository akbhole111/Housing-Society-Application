package com.example.chatapp.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.chatapp.ChatDetailActivity;
import com.example.chatapp.Models.User;
import com.example.chatapp.R;
import com.example.chatapp.imageRotation;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder>{


    ArrayList<User> list;
    Context context;

    public UserAdapter(ArrayList<User> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view= LayoutInflater.from(context).inflate(R.layout.sample_show_user,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        User users=list.get(position);
//        Picasso.get()
//                .load(users.getProfilePic())
//                .fit().centerInside()
//                .error(R.drawable.profile_avatar)
//               //.rotate(imageRotation.getCameraPhotoOrientation(users.getProfilePic()))
//                .placeholder(R.drawable.profile_avatar)
//                .into(holder.image);

        Glide.with(context)
                .load(users.getProfilePic()) // Uri of the picture
                .apply (RequestOptions.placeholderOf(R.drawable.profile_avatar))
                .into(holder.image);

        holder.username.setText(users.getUserName());


//        Picasso.with(MainActivity.this)
//                .load(imageURL) // web image url
//                .fit().centerInside()
//                .transform(transformation)
//                .rotate(90)                    //if you want to rotate by 90 degrees
//                .error(R.drawable.ic_launcher)
//                .placeholder(R.drawable.ic_launcher)
//                .into(imageview)
//    });

        FirebaseDatabase.getInstance().getReference().child("chats")
                        .child(FirebaseAuth.getInstance().getUid()+users.getUserId())
                                .orderByChild("timestamp")
                                        .limitToLast(1)
                                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                        if(snapshot.hasChildren())
                                                        {
                                                            for (DataSnapshot snapshot1:snapshot.getChildren())
                                                            {
                                                                holder.lastMessage.setText(snapshot1.child("message").getValue().toString());
                                                            }
                                                        }
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError error) {

                                                    }
                                                });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context, ChatDetailActivity.class);
                intent.putExtra("userId",users.getUserId());
                intent.putExtra("profilePic",users.getProfilePic());
                intent.putExtra("userName",users.getUserName());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        ImageView image;
        TextView username,lastMessage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image=itemView.findViewById(R.id.profile_image);
            username=itemView.findViewById(R.id.username);
            lastMessage=itemView.findViewById(R.id.LastMessage);
        }
    }

}
